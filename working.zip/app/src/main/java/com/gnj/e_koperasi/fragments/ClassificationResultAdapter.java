package com.gnj.e_koperasi.fragments;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.gnj.e_koperasi.databinding.ItemClassificationResultBinding;
import org.tensorflow.lite.support.label.Category;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

/** Adapter for displaying the list of classifications for the image */
public class ClassificationResultAdapter
        extends RecyclerView.Adapter<ClassificationResultAdapter.ViewHolder> {
    private static final String NO_VALUE = "--";
    private List<Category> categories = new ArrayList<>();
    private int adapterSize = 0;

    private HashMap<String, String> labelMap = new HashMap<>(); // Add this HashMap to store the numbers and their corresponding texts

    // Method to read labels from the "labels.txt" file and store them in a HashMap
    private void readLabelsFromFile(Context context, String filePath) {
        try {
            InputStream inputStream = context.getAssets().open(filePath);
            BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));

            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(" ");
                if (parts.length == 2) {
                    String number = parts[0].trim();
                    String text = parts[1].trim();
                    labelMap.put(number, text);
                }
            }
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    public void updateResults(List<Category> categories) {
        List<Category> sortedCategories = new ArrayList<>(categories);
        Collections.sort(sortedCategories, new Comparator<Category>() {
            @Override
            public int compare(Category category1, Category category2) {
                return category1.getIndex() - category2.getIndex();
            }
        });
        this.categories = new ArrayList<>(Collections.nCopies(adapterSize, null));
        int min = Math.min(sortedCategories.size(), adapterSize);
        for (int i = 0; i < min; i++) {
            this.categories.set(i, sortedCategories.get(i));
        }
        notifyDataSetChanged();
    }

    public void updateAdapterSize(int size) {
        adapterSize = size;
    }

    // Method to update the labelMap in the adapter
    public void updateLabelMap(HashMap<String, String> labelMap) {
        this.labelMap.clear();
        this.labelMap.putAll(labelMap);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Update the layout file name to match your layout
        ItemClassificationResultBinding binding = ItemClassificationResultBinding
                .inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.bind(categories.get(position), labelMap); // Pass the labelMap to the ViewHolder
    }

    @Override
    public int getItemCount() {
        return categories.size();
    }

    /** Data structure for items in list */
    public static class ViewHolder extends RecyclerView.ViewHolder {
        private final TextView tvLabel;
        private final TextView tvScore;

        DatabaseReference itemsRef = FirebaseDatabase.getInstance().getReference("item");
        public ViewHolder(@NonNull ItemClassificationResultBinding binding) {
            super(binding.getRoot());
            tvLabel = binding.tvLabel;
            tvScore = binding.tvScore;
        }

        public void bind(Category category, HashMap<String, String> labelMap) {
            if (category != null) {
                String categoryLabel = category.getLabel();
                String itemText = labelMap.get(categoryLabel);

                Query query = itemsRef.orderByChild("item_name").equalTo(itemText);
                query.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.exists()) {
                            for (DataSnapshot childSnapshot : dataSnapshot.getChildren()) {
                                String item_name = childSnapshot.child("item_name").getValue(String.class);
                                String item_price = childSnapshot.child("item_price").getValue(String.class);
                                if (item_name != null && item_name.equals(itemText)) {
                                    tvLabel.setText(item_name + " (" + item_price + ")");
                                    tvScore.setText(String.format(Locale.US, "%.2f%%", category.getScore() * 100));
                                    return; // Add this return statement to exit the loop after finding the correct item
                                }
                            }
                        } else {
                            tvLabel.setText(categoryLabel); // Use the updated category label from the labelMap
                            tvScore.setText(String.format(Locale.US, "%.2f%%", category.getScore() * 100));
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        // Handle the error if needed
                    }
                });
            } else {
                tvLabel.setText(NO_VALUE);
                tvScore.setText(NO_VALUE);
            }
        }
    }
}