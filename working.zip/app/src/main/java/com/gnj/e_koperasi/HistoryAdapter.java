package com.gnj.e_koperasi;

public class HistoryAdapter {
}
